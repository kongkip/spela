from setuptools import setup

setup(
    name='spela',
    version='0.0.0',
    packages=['spela', 'utils'],
    url='https://github.com/kongkip/spela.git',
    long_description_content_type="text/markdown",
    author='Evans Kiplagat',
    author_email='evanskiplagat3@gmail.com',
    license='MIT',
    description='', install_requires=['numpy']
)
